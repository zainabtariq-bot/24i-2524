DAV Lab 9 — All Six D3 Tasks

Open index.html with VS Code Live Server (internet required for D3.js and world GeoJSON).

Datasets:
- university.csv, population.csv, pakistan_cities.csv: user-uploaded originals.
- flights.csv: illustrative sample from earlier project; replace if instructor provides the actual file.

IMPORTANT: pakistan_cities.csv pop values are in MILLIONS (e.g., Karachi 16.0).
Labels use >1 million, as required by the manual.

Charts: treemap, collapsible dendrogram, draggable flight network, world choropleth, Pakistan point map, combined spatial encoding.
